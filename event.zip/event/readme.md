# Event Booking System

This is a simple Event Booking System web application that allows users to browse, view, and book tickets for various events. The system includes pages for viewing events, booking tickets, and confirming bookings.

## Features

- **Event Listing:** The home page displays a list of upcoming events with images, dates, and descriptions.
- **Event Details:** Users can click on an event to view more details and book tickets.
- **Booking Form:** A form is provided to collect user details and ticket preferences.
- **Confirmation Page:** After booking, users are shown a confirmation page with the booking details.

## Pages

### 1. `index.html`
The home page displays a list of events, including their titles, dates, descriptions, and images. The events are dynamically loaded from a JavaScript array.

### 2. `events.html`
This page provides a detailed view of a selected event. It includes a booking form where users can enter their details and select ticket options.

### 3. `confirmation.html`
This page displays a confirmation message and the details of the booking. Users can print the confirmation or book another event.

## Styles

### `styles.css`
- **Responsive Design:** The layout is responsive, with event cards adjusting based on the screen size.
- **Consistent Look:** The site uses a consistent color scheme and font style throughout.
- **Event Cards:** Events are displayed as cards with hover effects.
- **Forms:** The booking form and confirmation buttons are styled for ease of use and accessibility.

## Scripts

### `script.js`
- **Event Data:** Events are stored in an array of objects, each containing details like title, date, description, and image.
- **Dynamic Loading:** The script dynamically loads event data into the home page and event details page.
- **Form Handling:** The booking form submission is handled by JavaScript, allowing the booking details to be displayed on the confirmation page.

## How to Use

1. **View Events:** Open `index.html` to see the list of available events.
2. **Book Tickets:** Click on an event to view its details and fill out the booking form.
3. **Confirm Booking:** After submitting the form, you will be redirected to the confirmation page where you can review and print your booking details.

## Technologies Used

- **HTML5:** For structuring the content.
- **CSS3:** For styling and layout.
- **JavaScript:** For dynamic content loading, form handling, and event management.
