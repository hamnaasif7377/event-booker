const events = [
    {
        "id": "1",
        "title": "Music Festival",
        "date": "2024-08-25",
        "description": "A thrilling music festival with various artists.",
        "image": "concert.png"
    },
    {
        "id": "2",
        "title": "Art Exhibition",
        "date": "2024-09-10",
        "description": "An exhibition showcasing contemporary art.",
        "image": "art.png"
    },
    {
        "id": "3",
        "title": "Tech Conference",
        "date": "2024-09-15",
        "description": "A conference for tech enthusiasts and professionals.",
        "image": "tech.png"
    },
    {
        "id": "4",
        "title": "Food Festival",
        "date": "2024-10-01",
        "description": "A festival featuring a variety of food trucks and stalls.",
        "image": "food.png"
    },
    {
        "id": "5",
        "title": "Outdoor Adventure",
        "date": "2024-10-15",
        "description": "An adventure event with hiking, kayaking, and more.",
        "image": "outdoors.png"
    },
    {
        "id": "6",
        "title": "Film Screening",
        "date": "2024-11-05",
        "description": "A screening of indie films with discussions.",
        "image": "film.png"
    },
    {
        "id": "7",
        "title": "Fashion Show",
        "date": "2024-11-20",
        "description": "A showcase of the latest fashion trends and designs.",
        "image": "fashion.png"
    },
    {
        "id": "8",
        "title": "Science Fair",
        "date": "2024-12-02",
        "description": "A fair featuring exciting science exhibits and experiments.",
        "image": "science.png"
    },
    {
        "id": "9",
        "title": "Holiday Market",
        "date": "2024-12-15",
        "description": "A market offering holiday gifts, crafts, and treats.",
        "image": "holiday.png"
    },
    {
        "id": "10",
        "title": "Fitness Expo",
        "date": "2025-01-10",
        "description": "An expo showcasing the latest in fitness and wellness.",
        "image": "fitness.png"
    },
    {
        "id": "11",
        "title": "Book Fair",
        "date": "2025-02-05",
        "description": "A fair with book signings, author talks, and more.",
        "image": "book.png"
    },
    {
        "id": "12",
        "title": "Gaming Convention",
        "date": "2025-03-20",
        "description": "A convention for gamers with tournaments and new releases.",
        "image": "gaming.png"
    },
    {
        "id": "13",
        "title": "Gardening Workshop",
        "date": "2025-04-10",
        "description": "A workshop on gardening techniques and plant care.",
        "image": "garden.png"
    },
    {
        "id": "14",
        "title": "Historical Tour",
        "date": "2025-05-15",
        "description": "A guided tour of historical landmarks in the city.",
        "image": "historical.png"
    },
    {
        "id": "15",
        "title": "Music Workshop",
        "date": "2025-06-25",
        "description": "A workshop for learning music production and theory.",
        "image": "music.jpg"
    }
];


// Load events into the #event-list section
function loadEvents() {
    const eventList = document.getElementById('event-list');

    if (!eventList) return;

    if (events.length === 0) {
        eventList.innerHTML = '<p>No events found.</p>';
        return;
    }

    eventList.innerHTML = ''; // Clear any existing content
    events.forEach(event => {
        const card = document.createElement('div');
        card.className = 'event-card';
        card.innerHTML = `
            <img src="${event.image}" alt="${event.title}">
            <div class="content">
                <h2>${event.title}</h2>
                <p>${event.date}</p>
                <p>${event.description}</p>
                <a href="events.html?event=${event.id}">View Details</a>
            </div>
        `;
        eventList.appendChild(card);
    });
}

// Load event details based on query parameter
function loadEventDetails() {
    const params = new URLSearchParams(window.location.search);
    const eventId = params.get('event');
    if (!eventId) return;

    const event = events.find(e => e.id === eventId);

    if (!event) {
        document.getElementById('event-details').innerHTML = '<p>Event not found.</p>';
        return;
    }

    const eventDetails = document.getElementById('event-details');
    eventDetails.innerHTML = `
        <h2>${event.title}</h2>
        <p>Date: ${event.date}</p>
        <p>${event.description}</p>
        <img src="${event.image}" alt="${event.title}">
        <form id="booking-form">
            <label for="name">Name:</label>
            <input type="text" id="name" required>
            
            <label for="email">Email:</label>
            <input type="email" id="email" required>
            
            <label for="ticket-type">Ticket Type:</label>
            <select id="ticket-type">
                <option value="vip">VIP</option>
                <option value="general">General Admission</option>
            </select>
            
            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" min="1" required>
            
            <button type="submit">Book Now</button>
        </form>
    `;
    document.getElementById('event-list').style.display = 'none';
    eventDetails.style.display = 'block';
}

// Handle form submission and save booking data
function handleFormSubmission(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const ticketType = document.getElementById('ticket-type').value;
    const quantity = document.getElementById('quantity').value;

    const bookingDetails = {
        name,
        email,
        ticketType,
        quantity,
        eventId: new URLSearchParams(window.location.search).get('event')
    };

    localStorage.setItem('bookingDetails', JSON.stringify(bookingDetails));

    window.location.href = 'confirmation.html';
}

// Display booking confirmation details
function displayBookingDetails() {
    const bookingDetails = JSON.parse(localStorage.getItem('bookingDetails'));

    if (!bookingDetails) {
        document.getElementById('booking-details').innerHTML = '<p>No booking details found.</p>';
        return;
    }

    const bookingDetailsDiv = document.getElementById('booking-details');
    bookingDetailsDiv.innerHTML = `
        <p><strong>Name:</strong> ${bookingDetails.name}</p>
        <p><strong>Email:</strong> ${bookingDetails.email}</p>
        <p><strong>Ticket Type:</strong> ${bookingDetails.ticketType}</p>
        <p><strong>Quantity:</strong> ${bookingDetails.quantity}</p>
        <p><strong>Event ID:</strong> ${bookingDetails.eventId}</p>
    `;

    localStorage.removeItem('bookingDetails'); // Clear booking details after displaying
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('event-list')) {
        loadEvents();
    }
    if (document.getElementById('event-details')) {
        loadEventDetails();
    }
    if (document.getElementById('booking-form')) {
        document.getElementById('booking-form').addEventListener('submit', handleFormSubmission);
    }
    if (document.getElementById('booking-details')) {
        displayBookingDetails();
    }
});
